# @aparte/json-render-pdf

Export a json-render document spec to an A4 PDF, in the browser or in Node, without React.

```bash
npm install @aparte/json-render-pdf
```

```ts
import { exportPdf } from '@aparte/json-render-pdf';

const { buffer, mime, filename, warnings } = await exportPdf(spec, { theme: 'clean' });

// with @aparte/plugin-artifacts
setupArtifacts({ onBinary: async (artifact) => exportPdf(specOf(artifact)) });
```

- Text flows over pages; a heading never ends a page alone; a long table repeats its header.
- Totals and tax are computed from the rows.
- The PDF standard fonts draw Latin-1 and the Windows-1252 extras (`€`, `—`, `’`…). Other characters
  (emoji, CJK) are left out and reported as `unsupported-char`.
- Images: `data:image/png` and `data:image/jpeg` are embedded; an `https` image is drawn as its text
  alternative (`remote-image`).

Uses [jsPDF](https://github.com/parallax/jsPDF) and jspdf-autotable inside. MIT.
