# @aparte/json-render-preview

Draw a json-render document spec as one self-contained HTML fragment.

```bash
npm install @aparte/json-render-preview
```

```ts
import { preview } from '@aparte/json-render-preview';

const { html, warnings } = preview(spec, { theme: 'classic' });
element.innerHTML = html;   // safe: see below
```

- **One `<article>`**, inline styles only (no stylesheet, no class), so it neither leaks into the
  host page nor picks up its styles.
- **Every string from the spec is escaped.** Links keep only `http`, `https` and `mailto`; images only
  `data:image/png`, `data:image/jpeg` and `https:`. Anything else is dropped with a warning
  (`unsafe-link`, `invalid-image`).
- **Never throws**, and draws a spec that is still arriving: missing children are reported, the rest
  is drawn. Nothing to draw → `html: ''`.
- The drawing is picked from the root component: `Document` today, other families later.

No dependency besides `@aparte/json-render-catalogs`. MIT.
