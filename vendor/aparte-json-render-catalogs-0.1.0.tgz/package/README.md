# @aparte/json-render-catalogs

json-render catalogs for documents, the themes, the export contract, and `prepareDocument()`.

```bash
npm install @aparte/json-render-catalogs
```

```ts
import { documentCatalog, prepareDocument } from '@aparte/json-render-catalogs';

documentCatalog.prompt();            // json-render's system prompt for the document catalog
const doc = prepareDocument(spec);   // a validated tree + warnings; throws ExportError only if nothing can be drawn
```

**The document catalog**: `Document` (root: title, theme, lang), `Section`, `Heading`, `Paragraph`,
`List`, `Table` (with computed `totals`, `taxRate`, `currency`), `KeyValue`, `Image`, `Quote`,
`Divider`, `PageBreak`. Props say what, never where: no positions, sizes, colours or fonts. Text
accepts **bold**, *italic*, `code` and links (`http`, `https`, `mailto`).

**Why `prepareDocument`**: json-render's `catalog.validate()` checks the shape of a spec but not each
element's props against its own type. `prepareDocument` does, element by element, and skips what
it rejects with a warning (`unknown-type`, `invalid-props`, `missing-child`, `cycle`, `orphan`,
`shared-child`, `too-deep`), so half a document — or a spec still streaming — still renders. An
element listed twice is drawn once, and nesting stops at 24 levels, so no spec can blow up the work.
Image sources are limited to embedded PNG/JPEG data and https (`isSafeImageSource`).

**Themes**: `clean` (sans) and `classic` (serif), plain values shared by the preview and every
exporter, so a spec looks the same on screen and in a file.

Built on `@json-render/core` 0.21.3 (pinned) and zod 4. MIT.
