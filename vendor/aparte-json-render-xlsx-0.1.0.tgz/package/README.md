# @aparte/json-render-xlsx

Export a json-render document spec to an Excel `.xlsx`, in the browser or in Node, without React.

```bash
npm install @aparte/json-render-xlsx
```

```ts
import { exportXlsx } from '@aparte/json-render-xlsx';

const { buffer, mime, filename, warnings } = await exportXlsx(spec);
```

- One worksheet, named after the title (sanitised, 31 characters at most). Text blocks are rows in
  column A; a key-value block is two columns.
- A table is a real cell range: bold header, numbers stored as numbers with a number format (money
  when the table has a currency). Multiply columns are `ROUND(B5*C5,2)` formulas, and the totals,
  tax and total rows are `SUM`, `ROUND(…*rate/100,2)` and addition formulas, each with its computed
  value cached, so the sheet is correct before Excel recalculates and stays live afterwards.
- A chart is written as a range of its data (a native Excel chart is out of scope).
- Images: `data:image/png` and `data:image/jpeg` are embedded; an `https` image is written as its
  text alternative (`remote-image`).

Uses [ExcelJS](https://github.com/exceljs/exceljs) inside. MIT.
