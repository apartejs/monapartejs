# @aparte/json-render-docx

Export a json-render document spec to a Word `.docx` (A4), in the browser or in Node, without React.

```bash
npm install @aparte/json-render-docx
```

```ts
import { exportDocx } from '@aparte/json-render-docx';

const { buffer, mime, filename, warnings } = await exportDocx(spec, { theme: 'clean' });
```

- The title is a Title paragraph (and the file's title property); headings 1 to 3 are Heading 1 to 3.
- Inline marks become bold, italic, monospace and hyperlink runs; lists use Word numbering (each numbered list restarts at 1).
- A table has a repeating header row, right-aligned numeric columns, computed multiply cells and the
  totals, tax and total rows, formatted for the document language and currency like the PDF.
- A chart is written as a table of its data (a native Word chart is out of scope).
- Images: `data:image/png` and `data:image/jpeg` are embedded; an `https` image is drawn as its text
  alternative (`remote-image`).

Uses [docx](https://github.com/dolanmiu/docx) inside. MIT.
